# Controller keyboard and mouse bindings

Open `/gusto gamepad` or select **Gamepad** in `/gusto`. Click
**Map: press controller, then keyboard key**:

1. Press the controller button/direction you want to map.
2. When the prompt changes, press the physical keyboard key or shortcut, or click the left, right, or middle mouse button.
3. Release the keys. Gusto saves the assignment and shows the result.

Ctrl, Alt and Shift combinations are captured. Escape or Cancel preserves the
old assignment. The captured press is consumed so it does not also trigger a
game action. The manual key picker and direct mouse-click assignment remain
available. Controller calibration is separate from this mapping wizard.

These are **keyboard bindings**, not native game-command IDs. For example,
map a stick direction to W and a button to Ctrl+1, then assign W and Ctrl+1 to
the actions you want in EverQuest's **Options → Keys**. Gusto sends a scan-code/modifier KeyCombo to EQ's own KeypressHandler, which
resolves your current Options / Keys bindings. It does not select a native
game command ID or rely on SendInput reaching EQ's buffered DirectInput path.

Direct **Assign LEFT / RIGHT / MIDDLE mouse click** buttons remain available.
Pressing holds the assigned key(s) or mouse button; releasing sends key/button
up. Two controller inputs sharing a key or modifier keep it down until both
release. Modifiers press before the shortcut key and release after it. Keys
release on disconnect, focus loss, menu/typing ownership, disable or remapping;
controller input must return to neutral before rearming. Already held physical
keys are not claimed by the controller; avoid holding the same key through
both devices simultaneously.

Examples:

```
/gusto gamepad bind 1 Space
/gusto gamepad bind 2 Ctrl+1
/gusto gamepad bind 3 MOUSE_RIGHT
/gusto gamepad bind 4 UNBOUND
```

Default examples: A/Cross = Space, B/Circle = C, X/Square = E, Y/Triangle = Q,
bumpers = T/Tab, Back = I, Start = F9, stick clicks = Home/5, D-pad = 1–4,
triggers = Insert/Delete, left stick = arrow keys, right stick = A/D/PageUp/
PageDown. Match them to your own EQ key settings; defaults are not inferred
from your client. Mouse-stick mode overrides that stick's direction bindings.

**Controller / stick / mouse settings** contains backend, slot, dead zone,
mouse stick (off/left/right), mouse speed, invert Y, generic axis layout and
raw-button calibration. The Auto backend tries XInput slots 1–4, then WinMM
joystick slots 1–16. Mouse control works in Gusto and game menus while keyboard
bindings pause. Pointer input requires the pointer inside the foreground game
client. Capturing a controller button does not replay its assigned click.

Assignments persist as `BindingFormat=2` and `KeyBinding0` through
`KeyBinding23` in `[Gamepad]` in `%LOCALAPPDATA%\Gusto\hud.ini`. Modifiers use
Shift `0x100`, Ctrl `0x200`, Alt `0x400` with the Windows virtual key in the low
byte; mouse actions are `0x800`–`0x802`. Old `BindingN` command IDs are ignored
on migration except mouse IDs 479–481, which retain their corresponding click.
Device calibration is preserved. Restore default keyboard bindings affects
only assignments. No other user's INI is shipped in the Windows package.


Stick directions hold their mapped keyboard key continuously while tilted; they
do not send repeated taps. The configured deadzone starts the hold; moving back
inside 70% of that deadzone releases it. This prevents small fluctuations near
the activation threshold from interrupting movement. Diagonals can hold two
keys. Center the stick after chat, menus, focus loss or reconnection to rearm.
A stick assigned to the mouse remains dedicated to pointer movement. Mouse
capture transfers no longer cancel controller keyboard holds or the mapping
wizard; actual keyboard focus loss still releases the keys.

The two-stage mapping wizard also accepts left, right, or middle mouse clicks
at the keyboard-key step. Click once, release, then close the menu to use the
assigned controller button. Mapping consumes the click and waits for its
release before resuming gameplay. Physical DirectInput mouse events and window
mouse messages both support this on Windows and Wine. Escape cancels mapping.

