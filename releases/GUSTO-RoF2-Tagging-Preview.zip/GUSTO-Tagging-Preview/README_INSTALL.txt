GUSTO RoF2 Tagging Preview - Windows and Wine

1. Fully exit EverQuest.
2. Back up your existing GUSTO.asi.
3. Copy this GUSTO.asi beside eqgame.exe in the supported RoF2 client.
4. Ensure a compatible 32-bit ASI loader is installed and enabled.
5. Restart EverQuest using your usual launcher.

Client: May 10 2013, 23:30:08 RoF2.

Target a living NPC, then use:
/tag local ^R^Assist

For shared tags, all participants need this Gusto build:
/tag join Gt123
Wait for EverQuest's join confirmation, then:
/tag chat ^R^Assist

Outgoing messages use GUSTOTAG. Incoming GUSTOTAG/GT and legacy ZEALTAG/ZT
messages are accepted. Original Zeal clients cannot read GUSTOTAG.

/tag status reports rendering and channel diagnostics.
Native tag text and live 3D marker visibility have been confirmed in game.
Server chat interoperability and broader device-reset testing still require
live confirmation. This is a preview.

See README.md and docs/tagging.md for commands, limitations, and tests.
Gusto is GPL-3.0-only; see LICENSE and THIRD_PARTY_NOTICES.md.
