GUSTO - EverQuest Rain of Fear 2
Windows and Wine Installation
================================

REQUIREMENTS
- EverQuest Rain of Fear 2 client
- 32-bit Windows-compatible ASI loader
- Windows 10/11 or Linux with Wine

INSTALLATION
1. Close EverQuest.
2. Back up your existing GUSTO.asi, if present.
3. Copy GUSTO.asi into the directory containing eqgame.exe.
4. Ensure a compatible ASI loader is installed and configured.
5. Start EverQuest using your normal launcher.

WINE
The same GUSTO.asi file is used under Wine.
Install and configure a compatible ASI loader in your
EverQuest Wine prefix.

FEATURES
- Native slow-turn key controls
- Toggle All Bags
- Nameplate hooks
- /gusto version command

COMPATIBILITY
Designed specifically for the tested EverQuest RoF2 client.
Other client versions are not guaranteed to work.

TROUBLESHOOTING
Keep a backup of your original client files.
If the client fails to start, remove GUSTO.asi and retry.

LICENSE
GPL-3.0-only. See LICENSE and THIRD_PARTY_NOTICES.md.

GUSTO is independent and is not affiliated with or endorsed
by Daybreak Game Company.
